def gibbonacci(n):
    """
    >>> gibbonacci(-512)
    615
    >>> gibbonacci(2)
    378225
    """
    if _______________________________:
        return _______________________
    else:
        return _______________________
