def make_digit_remover(i):
    """
    >>> remove_two = make_digit_remover(2)
    >>> remove_two(232018)
    23
    >>> remove_two(23)
    0
    >>> remove_two(99)
    99
    """
    def remove(_______):
    removed = _______________________
    while _______________________ > 0:
        _____________________________
        removed = removed // 10
        if __________________________:
            _________________________
    return __________________________
return __________________________