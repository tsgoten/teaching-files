def subsets(lst, n):
    """
    >>> three_subsets = subsets(list(range(5)), 3)
    >>> for subset in sorted(three_subsets):
    ...     print(subset)
    [0, 1, 2]
    [0, 1, 3]
    [0, 1, 4]
    [0, 2, 3]
    [0, 2, 4]
    [0, 3, 4]
    [1, 2, 3]
    [1, 2, 4]
    [1, 3, 4]
    [2, 3, 4]
    """
    if n == 0:
        return [[]]
    elif len(lst) == n:
        return [lst]
    with_first = [[lst[0]] + rest for rest in subsets(lst[1:], n - 1)]
    wout_first = [rest for rest in subsets(lst[1:], n)]
    return with_first + wout_first
